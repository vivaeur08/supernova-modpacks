bossbar set minecraft:phase_4_mobs name "Wave 2"
bossbar set minecraft:phase_4_mobs max 24

scoreboard players set @e[type=marker,tag=master] dragon_phase 8

execute as @a[nbt={Dimension:"minecraft:the_end"}] at @s run playsound minecraft:block.beacon.power_select master @a ~ ~ ~ 2 2

summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}
summon piglin ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_sword"}],HandDropChances:[0.0f,0.0f]}

summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}
summon piglin_brute ~ ~ ~ {Tags:["phase_4_mob"],IsImmuneToZombification:true,DeathLootTable:"minecraft:empty",HandItems:[{Count:1,id:"minecraft:golden_axe"}],HandDropChances:[0.0f,0.0f]}

execute in minecraft:the_end run spreadplayers 0 0 0 5 false @e[tag=phase_4_mob]