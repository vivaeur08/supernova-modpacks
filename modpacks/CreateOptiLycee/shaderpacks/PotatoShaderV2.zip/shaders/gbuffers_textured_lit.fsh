#version 120

/*
 * PotatoShade - gbuffers_textured_lit.fsh
 *
 * Base: vanilla texture * lightmap * vertex-color math, same as no shader
 * at all. Added on top of that, each independently toggleable:
 *
 * 1. FOG - blends geometry into the sky color at the render-distance edge
 *    using Iris's built-in fog data (matches vanilla exactly). Without
 *    this, terrain stops rendering abruptly at the edge of view distance
 *    instead of fading out, which is what caused the visible horizon line
 *    in earlier versions of this pack.
 *
 * 2. Fake directional shading - NOT real shadows. Brightens faces angled
 *    toward the sun/moon and dims faces angled away, using only the
 *    surface normal - no shadow map, no occlusion by other blocks. It
 *    adds a bit of visual depth for near-zero cost, but a block sitting
 *    in the shade of another block will NOT actually go dark from this
 *    alone (only vanilla's baked lightmap does that).
 *
 * 3. Godray/torch reject data - writes this pixel's vanilla block-light
 *    level to colortex1 (2nd render target, see DRAWBUFFERS below) so the
 *    final.fsh godray pass can tell "sky" apart from "sitting right next
 *    to a torch/lantern". One extra 8-bit target, no extra render pass.
 *
 * REMOVED per request: this file used to also add a fake handheld glow
 * near the camera when holding a light-emitting item (this shaderpack's
 * own effect, unrelated to the separate LambDynamicLights mod - see
 * README). That code path, and the heldBlockLightValue uniforms it used,
 * have been deleted outright, not just toggled off.
 */

#include "/lib/settings.glsl"

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec3 sunPosition;
uniform vec3 moonPosition;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;
varying vec3 viewNormal;

void main() {
    vec4 color = texture2D(texture, texcoord);
    if (color.a < 0.1) discard;
    color *= texture2D(lightmap, lmcoord); // vanilla block/sky light + AO
    color *= glcolor;

#ifdef ENABLE_FAKE_SHADING
    vec3 n = normalize(viewNormal);
    // Use whichever of sun/moon is actually above the horizon-ish (roughly
    // opposite each other in vanilla's sky model) by picking the one that
    // faces the surface more directly.
    float NdotSun  = dot(n, normalize(sunPosition));
    float NdotMoon = dot(n, normalize(moonPosition));
    float NdotL = max(NdotSun, NdotMoon);
    float shade = mix(0.85, 1.12, clamp(NdotL * 0.5 + 0.5, 0.0, 1.0));
    color.rgb *= mix(1.0, shade, SHADER_INTENSITY);
#endif

    float fogDist = length(viewPos);
    // Degenerate/zero fog range (start==end) means the game hasn't
    // configured real distance fog for this draw - The End doesn't use
    // normal fog the way the Overworld/Nether do, so this happens there.
    // Treat that as "fog off" (factor 0), NOT "fog maxed out": the old
    // max(range, 0.001) guard against divide-by-zero instead forced an
    // almost-zero range, which snapped fogFactor to 1.0 for virtually any
    // distance - replacing every block with solid fog color (near-black
    // in the End's void), which is exactly the "no blocks, just sky and
    // entities" bug. Entities stayed visible because things like an
    // Enderman's glowing eyes render fullbright/fog-immune in vanilla, so
    // they cut through even when everything else was crushed to fog color.
    float fogRange = gl_Fog.end - gl_Fog.start;
    float fogFactor = (fogRange > 0.5) ? clamp((fogDist - gl_Fog.start) / fogRange, 0.0, 1.0) : 0.0;
    color.rgb = mix(color.rgb, gl_Fog.color.rgb, fogFactor);

    gl_FragData[0] = color;
    // lmcoord.x = vanilla block-light lightmap coordinate (~0 = no nearby
    // light source, ~1 = right next to a torch/lantern/glowstone/etc).
    gl_FragData[1] = vec4(lmcoord.x, 0.0, 0.0, 1.0);
}
/* DRAWBUFFERS:01 */
