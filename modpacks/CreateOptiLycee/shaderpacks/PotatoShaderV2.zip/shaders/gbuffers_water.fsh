#version 120

/*
 * PotatoShade - gbuffers_water.fsh
 * REVERTED TO DEFAULT PER REQUEST: this file previously added a fresnel
 * rim, blue-teal tint push, animated shimmer, and a wavy UV ripple. All of
 * that has been removed - water now renders with the exact same math as
 * plain terrain (texture * lightmap * vertex color + fog), i.e. it looks
 * like vanilla water under this shaderpack's fake directional shading,
 * nothing water-specific added on top.
 *
 * This file still exists (rather than being deleted) for one reason only:
 * it writes the block-light value to colortex1 (DRAWBUFFERS:01, see
 * gbuffers_textured_lit.fsh for the full explanation), which is what lets
 * the godray pass in final.fsh ignore a torch/lantern reflected in or
 * next to water. That write has zero visible effect on how water looks -
 * it's invisible bookkeeping for a different feature.
 */

#include "/lib/settings.glsl"

uniform sampler2D texture;
uniform sampler2D lightmap;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
    vec4 color = texture2D(texture, texcoord);
    if (color.a < 0.02) discard;
    color *= texture2D(lightmap, lmcoord);
    color *= glcolor;

    float fogDist = length(viewPos);
    // Degenerate fog range (start==end, e.g. in The End) means "no fog
    // configured", not "maximum fog" - see gbuffers_textured_lit.fsh for
    // the full explanation of the bug this fixes.
    float fogRange = gl_Fog.end - gl_Fog.start;
    float fogFactor = (fogRange > 0.5) ? clamp((fogDist - gl_Fog.start) / fogRange, 0.0, 1.0) : 0.0;
    color.rgb = mix(color.rgb, gl_Fog.color.rgb, fogFactor);

    gl_FragData[0] = color;
    gl_FragData[1] = vec4(lmcoord.x, 0.0, 0.0, 1.0);
}
/* DRAWBUFFERS:01 */
