#version 120

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

    float fogDist = length(viewPos);
    // Degenerate fog range (start==end, e.g. in The End) means "no fog
    // configured", not "maximum fog" - see gbuffers_textured_lit.fsh for
    // the full explanation of the bug this fixes.
    float fogRange = gl_Fog.end - gl_Fog.start;
    float fogFactor = (fogRange > 0.5) ? clamp((fogDist - gl_Fog.start) / fogRange, 0.0, 1.0) : 0.0;
    color.rgb = mix(color.rgb, gl_Fog.color.rgb, fogFactor);

    gl_FragColor = color;
}
