#version 120

/*
 * PotatoShade - gbuffers_skytextured.fsh
 * Sun and moon. A brightness/vividness lift here, plus a dedicated
 * radial glow computed in final.fsh (see ENABLE_SUNMOON_GLOW there) using
 * the same sunPosition/moonPosition uniforms already used for godrays -
 * that's the real "look better" upgrade; this file just keeps the small
 * existing brightness lift on the actual texture pixels.
 */

#include "/lib/settings.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.02) discard;

#ifdef ENABLE_SKY_ENHANCE
    color.rgb *= mix(1.0, 1.2, SHADER_INTENSITY);
#endif

    gl_FragColor = color;
}
