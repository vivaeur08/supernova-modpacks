#version 120

/*
 * PotatoShade - gbuffers_textured_lit.vsh
 * Lit textured geometry. Terrain, entities, the held item/hand, weather,
 * and falling blocks all fall back to this program - it covers most of
 * what you actually see.
 */

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;    // camera-relative position, for fog + dynamic light
varying vec3 viewNormal; // for fake directional shading

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
}
