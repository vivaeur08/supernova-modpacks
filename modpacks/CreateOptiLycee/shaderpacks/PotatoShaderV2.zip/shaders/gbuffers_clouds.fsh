#version 120

/*
 * PotatoShade - gbuffers_clouds.fsh
 * Previously clouds fell back to gbuffers_textured (shared with
 * particles). A dedicated program lets them be softened without touching
 * anything else: slightly less opaque and a touch brighter so they read
 * less like solid grey boxes, a warm push when they're catching
 * dawn/dusk light (same signal as the sky - vertex color's own warmth),
 * and fog fade so they don't pop in/out with a hard edge at the render
 * distance boundary. No extra texture reads.
 */

#include "/lib/settings.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.05) discard;

#ifdef ENABLE_SKY_ENHANCE
    color.a *= mix(1.0, 0.85, SHADER_INTENSITY);
    color.rgb = mix(color.rgb, color.rgb * 1.08 + 0.02, SHADER_INTENSITY * 0.5);
    float warmth = clamp(color.r - color.b, 0.0, 1.0);
    color.rgb = mix(color.rgb, color.rgb * vec3(1.1, 1.0, 0.92), warmth * SHADER_INTENSITY);
#endif

    float fogDist = length(viewPos);
    // Degenerate fog range (start==end, e.g. in The End) means "no fog
    // configured", not "maximum fog" - see gbuffers_textured_lit.fsh for
    // the full explanation of the bug this fixes.
    float fogRange = gl_Fog.end - gl_Fog.start;
    float fogFactor = (fogRange > 0.5) ? clamp((fogDist - gl_Fog.start) / fogRange, 0.0, 1.0) : 0.0;
    color.rgb = mix(color.rgb, gl_Fog.color.rgb, fogFactor);

    gl_FragColor = color;
}
