#version 120

/*
 * PotatoShade - world1/gbuffers_water.fsh (End dimension override)
 * Same reasoning and same trade-off as world1/gbuffers_textured_lit.fsh -
 * see that file for the full explanation. Covers any liquid placed in
 * The End (rare, but kept consistent rather than leaving a gap).
 */

uniform sampler2D texture;
uniform sampler2D lightmap;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    vec4 color = texture2D(texture, texcoord);
    if (color.a < 0.02) discard;
    color *= texture2D(lightmap, lmcoord);
    color *= glcolor;

    gl_FragColor = color;
}
