#version 150

/*
 * PotatoShade - world1/final.fsh (End dimension override)
 *
 * Iris supports per-dimension overrides via world1 = The End, world-1 =
 * the Nether. Files here replace the matching root shaders/ file only
 * while in that dimension.
 *
 * Best-effort fix for "the sky breaks after killing the Ender Dragon": the
 * End's lighting is unusual (normally near-black, then a scripted bright
 * flash during the dragon-death sequence). Strong contrast/saturation/
 * vignette/godray math can behave oddly on that kind of atypical
 * brightness swing. This override uses much gentler grading and skips
 * godrays entirely (there's no real sun/moon in the End for that to
 * target correctly anyway) so the End renders more predictably.
 *
 * See also world1/gbuffers_textured_lit.fsh and world1/gbuffers_water.fsh
 * in this same folder - the actual fix for End terrain being invisible.
 *
 * HONEST NOTE: I haven't been able to see what "breaks" looks like, so
 * this is a best-effort mitigation, not a confirmed fix. If the sky still
 * looks wrong in the End with this in place, a screenshot would let me
 * pin down the actual cause instead of guessing again.
 *
 * SANITIZE: guards against NaN/Inf ever reaching the screen as chaotic
 * per-pixel static (which is what colorful noise usually means) - see
 * README v6 changelog, "End void shows colorful static". The existing
 * clamp() below was NOT a reliable guard against this: clamp()'s
 * behavior when fed NaN is implementation-defined per the GLSL spec, not
 * guaranteed to produce a safe value on every GPU/driver - explicitly
 * checking isnan()/isinf() before any math is the only reliable fix.
 */

uniform sampler2D colortex0;

in vec2 texcoord;
out vec4 fragColor;

vec3 sanitize(vec3 c) {
    c.r = (isnan(c.r) || isinf(c.r)) ? 0.0 : c.r;
    c.g = (isnan(c.g) || isinf(c.g)) ? 0.0 : c.g;
    c.b = (isnan(c.b) || isinf(c.b)) ? 0.0 : c.b;
    return clamp(c, 0.0, 4.0);
}

void main() {
    vec3 color = sanitize(texture(colortex0, texcoord).rgb);

    // Minimal grading only - no vignette, no godrays, no strong contrast.
    color = clamp((color - 0.5) * 1.03 + 0.5, 0.0, 1.0);

    float dither = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    color += (dither - 0.5) / 255.0;

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
