#version 120

/*
 * PotatoShade - world1/gbuffers_textured_lit.fsh (End dimension override)
 *
 * This covers terrain, entities, and the held item/hand in The End
 * specifically (Iris checks for a world1/ override at EVERY step of the
 * normal fallback chain, not just the top of it - so this also replaces
 * gbuffers_entities/gbuffers_terrain/etc for the End, same as the root
 * gbuffers_textured_lit.fsh does everywhere else).
 *
 * WHY THIS FILE EXISTS: End terrain was reported invisible (only sky and
 * entities showing) with the shared root gbuffers_textured_lit.fsh. Two
 * targeted fixes at that shared file (a degenerate-fog-range guard, then
 * a NaN/buffer-clear guard) did NOT resolve it - so rather than keep
 * guessing at exactly what's going wrong in the shared code path on this
 * specific hardware/driver, this file sidesteps the question entirely:
 * it is the simplest possible correct block renderer - one texture read,
 * one lightmap read, vertex color, done. No fog math (gl_Fog.start/end
 * are exactly what's under suspicion, so this doesn't touch them at
 * all), no multiple render targets, no division of any kind. If blocks
 * still don't render with THIS file in place, the problem is not in this
 * shaderpack's code - it would point to something at the Iris/Sodium/
 * driver level specific to your setup, and a screenshot plus your exact
 * Iris and Sodium version numbers would be the next useful thing to see.
 *
 * TRADE-OFF, STATED PLAINLY: this drops fog, fake directional shading,
 * and the torch/lantern godray-reject data for the End only. All three
 * are minor here - the End is a small, bounded void space (little need
 * for distance fog), and godrays are already fully disabled in the End
 * (see world1/final.fsh), so the reject data has nothing to feed anyway.
 * Overworld and Nether are untouched - they still get the full version.
 */

uniform sampler2D texture;
uniform sampler2D lightmap;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    vec4 color = texture2D(texture, texcoord);
    if (color.a < 0.02) discard;
    color *= texture2D(lightmap, lmcoord);
    color *= glcolor;

    gl_FragColor = color;
}
