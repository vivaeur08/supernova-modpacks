#version 120

/*
 * PotatoShade - world1/gbuffers_water.vsh (End dimension override)
 * Same reasoning as world1/gbuffers_textured_lit.vsh - see that file.
 */

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
}
