#version 150

/*
 * PotatoShade - final.vsh
 * Core-profile (Iris compiles composite/final in a core GLSL context on
 * this setup, so legacy gl_TexCoord/gl_Vertex/ftransform aren't available
 * here). Draws one triangle that overshoots the screen on two sides,
 * covering the whole visible area with 3 vertices and zero vertex buffer -
 * standard core-profile full-screen-pass technique.
 */

out vec2 texcoord;

void main() {
    vec2 uv = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
    texcoord = uv;
    gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0);
}
