/*
 * PotatoShade - lib/settings.glsl
 * Shared options, included via: #include "/lib/settings.glsl"
 *
 * NOTE: If these don't show up in the in-game "Shader Options" menu (Iris's
 * option scanner isn't guaranteed to look inside included files on every
 * version), just edit the values below with a text editor - the pack reads
 * this file the same either way.
 */

// ---------------------------------------------------------------------
// Master intensity - scales most effects below.
// 0.0 = vanilla look, 1.0 = default, 2.0 = strongest.
#define SHADER_INTENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]

// ---------------------------------------------------------------------
// Final-pass color grading
#define ENABLE_CONTRAST
#define ENABLE_SATURATION
#define ENABLE_VIGNETTE
//#define ENABLE_SHARPEN          // extra GPU cost, OFF by default

const float BASE_CONTRAST     = 1.12;
const float BASE_SATURATION   = 1.25;
const float VIGNETTE_STRENGTH = 0.45;
const float SHARPEN_STRENGTH  = 0.25;

// ---------------------------------------------------------------------
// Godrays (screen-space, approximate - see README for how this works
// and its one real limitation: no true light-shaft occlusion by terrain).
// SUN ONLY now (moon godrays removed per request - also cuts the ray
// pass's cost roughly in half, since it was previously running twice,
// once per light). GODRAY_BLOCKLIGHT_CUTOFF/FEATHER control the
// torch/lantern reject: any screen pixel whose vanilla block-light level
// is at/above the cutoff is excluded from the ray sample. GODRAY_SOFT_CEILING
// is a soft (not hard) cap on how bright the ray effect can ever get.
// Both STRENGTH and CEILING turned down further this round - the
// previous defaults still read as too strong.
#define ENABLE_GODRAYS
#define GODRAY_STRENGTH 0.35 // [0.0 0.15 0.25 0.35 0.5 0.75 1.0]
//#define GODRAY_HIGH_QUALITY     // 16 samples instead of 8, more GPU cost, OFF by default
const float GODRAY_BLOCKLIGHT_CUTOFF  = 0.45; // below this = treated as "not a light source"
const float GODRAY_BLOCKLIGHT_FEATHER = 0.20; // width of the soft transition above the cutoff
const float GODRAY_CANOPY_THRESHOLD   = 0.30; // was hardcoded 0.5 - lets some light through leaves
const float GODRAY_SOFT_CEILING       = 0.28; // asymptotic max additive brightness, any strength

// ---------------------------------------------------------------------
// Sun/moon glow (final pass, keyed off the same sunPosition/moonPosition
// already used for godrays - no new texture reads beyond one depth
// sample, see below). See README: a shaderpack can recolor/glow the
// EXISTING vanilla sun/moon texture, it cannot swap in a different image
// - that needs a resource pack.
// FIXED: this used to glow straight through terrain/mountains, because it
// only checked the sun/moon's screen-space position, never whether
// something solid was actually drawn there. It now samples depthtex0 (the
// scene's existing depth buffer - already computed for free every frame,
// this just reads it) at that exact position: if solid geometry is closer
// than the far/sky plane, the glow is suppressed entirely.
#define ENABLE_SUNMOON_GLOW
const float SUN_GLOW_RADIUS    = 0.14;
const float SUN_GLOW_STRENGTH  = 0.28;
const vec3  SUN_GLOW_COLOR     = vec3(1.0, 0.85, 0.55);
const float MOON_GLOW_RADIUS   = 0.08;
const float MOON_GLOW_STRENGTH = 0.18;
const vec3  MOON_GLOW_COLOR    = vec3(0.75, 0.85, 1.0);

// ---------------------------------------------------------------------
// Fake directional "shading" (NOT real shadows - see README).
#define ENABLE_FAKE_SHADING

// ---------------------------------------------------------------------
// Sky / sun / moon / cloud polish - all near-zero extra cost (no new
// texture reads beyond what's already being sampled).
#define ENABLE_SKY_ENHANCE

// ---------------------------------------------------------------------
// Water: reverted to plain vanilla-equivalent rendering per request (no
// ripple/tint/sparkle) - see gbuffers_water.fsh. It still writes the
// torch/lantern-reject mask (colortex1) so that system keeps working for
// water tiles too, but that has zero effect on how the water looks.

// ---------------------------------------------------------------------
// TEST TOGGLE - turn ON to confirm the final pass is running (whole
// screen goes bright magenta). Turn back OFF for normal play.
//#define DEBUG_TINT
