#version 150

/*
 * PotatoShade - final.fsh
 *
 * The only pass that does real work in this pack. Runs once per frame on
 * the already-rendered scene. No shadow map, no deferred G-buffer pass -
 * those are the expensive parts of a typical shaderpack, avoided on
 * purpose for very weak GPUs (e.g. a GT 630). There IS now one extra
 * lightweight colortex1 buffer (see TORCH/LANTERN REJECT below) - it's a
 * single 8-bit value per pixel with no extra render pass, so the cost is
 * negligible next to a real shadow map or deferred setup.
 *
 * GODRAYS - HOW AND WHY THIS IS CHEAP:
 * Real godrays need a shadow map to know exactly what's blocking the sun.
 * We don't have one, so this uses a well-known cheap approximation
 * instead: find the sun/moon's position on screen, then radially sample
 * the already-rendered image toward it, only keeping bright (sky-colored)
 * samples. Where there's a clear, bright path to the sun, you get rays;
 * where terrain blocks the view, the samples are dark and contribute
 * little. It's an approximation, not physically accurate occlusion - a
 * cliff edge won't cast a perfectly crisp ray shape - but it looks
 * reasonable and costs only a handful of extra texture reads, and only
 * when the sun/moon is actually near/inside the view.
 *
 * TORCH/LANTERN REJECT: colortex1 holds a per-pixel "block light level"
 * mask, written by gbuffers_textured_lit.fsh and gbuffers_water.fsh (see
 * those files - each stamps its own lmcoord.x into colortex1 via a
 * DRAWBUFFERS:01 output). Sky/sun/moon pixels never write to colortex1,
 * so they stay 0 there (buffers clear to 0 every frame). The ray march
 * below reads this mask at each sample and fades out any sample that sits
 * on a torch/lantern/glowstone etc. instead of open sky, so a nearby
 * light source can no longer fake a sunbeam.
 *
 * SUN ONLY: moon godrays removed per request - computeGodrays() is now
 * called once instead of twice, which is a genuine, direct FPS win (it's
 * the single most expensive thing in this pass), not just a visual change.
 *
 * LEAF CANOPY: the "is this sample bright enough to count as light" test
 * used to require luma >= 0.5, which a sunlit leaf/foliage texture rarely
 * reaches (leaves are just darker than open sky, even in full sun) - so a
 * tree canopy read as a hard wall with zero light getting through, unlike
 * real dappled sunlight. GODRAY_CANOPY_THRESHOLD (0.30, see settings.glsl)
 * lowers that bar so moderately-lit foliage can contribute some light.
 * HONEST LIMITATION: this is still only 8-16 samples along one straight
 * line per pixel, not per-leaf-gap raytracing, so don't expect crisp
 * individual beams between leaves - just noticeably less of a hard block.
 * A per-leaf-gap-accurate version would need far more samples than a
 * GT 630 can spare at 60fps.
 *
 * SOFT CEILING: the ray contribution goes through a Reinhard-style soft
 * clip (x / (1+x)) before being added, curving toward GODRAY_SOFT_CEILING
 * instead of growing without bound at high GODRAY_STRENGTH. STRENGTH's
 * default and the ceiling itself were both turned down again this round
 * (0.75->0.35 and 0.50->0.28) - the previous version still read as too
 * strong/too much, not just "blinding only at Maximum".
 *
 * SUN/MOON GLOW: a separate, cheap radial glow around the sun and moon's
 * on-screen position (reusing the same gbufferProjection math the godray
 * pass already does). This is the practical way a shader CAN make the
 * sun/moon look better: recolor/glow what's already being drawn. It can't
 * replace the actual sun.png/moon_phases.png image with a different
 * design - that's a resource pack's job, not a shader's.
 * FIXED - GLOW THROUGH BLOCKS: this used to glow through terrain/
 * mountains, because it only checked the sun/moon's screen-space
 * position, never whether something solid was actually drawn there. It
 * now samples depthtex0 (the scene's existing depth buffer - already
 * computed for free every frame, this just reads it) at that exact
 * position and suppresses the glow if solid geometry is closer than the
 * sky/far plane. One extra depth read per light, effectively free.
 */

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform float viewWidth;
uniform float viewHeight;
uniform vec3 sunPosition;   // eye-space direction to the sun
uniform vec3 moonPosition;  // eye-space direction to the moon
uniform mat4 gbufferProjection;

in vec2 texcoord;
out vec4 fragColor;

#include "/lib/settings.glsl"

#ifdef GODRAY_HIGH_QUALITY
const int GODRAY_SAMPLES = 16;
#else
const int GODRAY_SAMPLES = 8;
#endif

// Defensive guard (see README v6 changelog - "End void shows colorful
// static" fix): if a NaN/Inf or wildly out-of-range value ever reaches
// colortex0 for a pixel (e.g. one nothing drew to, or a driver quirk on
// older hardware), letting it flow through contrast/saturation/dither
// unchecked is exactly what produces that kind of chaotic per-pixel
// noise. This forces any broken channel to a plain 0 (black) instead,
// so the worst case becomes "a plain dark pixel", never static.
vec3 sanitize(vec3 c) {
    c.r = (isnan(c.r) || isinf(c.r)) ? 0.0 : c.r;
    c.g = (isnan(c.g) || isinf(c.g)) ? 0.0 : c.g;
    c.b = (isnan(c.b) || isinf(c.b)) ? 0.0 : c.b;
    return clamp(c, 0.0, 4.0);
}

vec3 adjustContrast(vec3 color, float amount) {
    return (color - 0.5) * amount + 0.5;
}

vec3 adjustSaturation(vec3 color, float amount) {
    float luma = dot(color, vec3(0.299, 0.587, 0.114));
    return mix(vec3(luma), color, amount);
}

#ifdef ENABLE_GODRAYS
vec3 computeGodrays(vec3 lightDirEye, vec2 uv) {
    vec4 clip = gbufferProjection * vec4(lightDirEye, 1.0);
    if (clip.w <= 0.0) return vec3(0.0); // light source behind the camera

    vec2 lightScreen = (clip.xy / clip.w) * 0.5 + 0.5;
    vec2 rayVec = uv - lightScreen;
    float rayLen = length(rayVec);
    if (rayLen > 0.9) return vec3(0.0); // cheap early-out when far off-screen

    vec2 step = rayVec / float(GODRAY_SAMPLES);
    vec2 samplePos = uv;
    vec3 accum = vec3(0.0);
    float weight = 1.0;

    for (int i = 0; i < GODRAY_SAMPLES; i++) {
        samplePos -= step;
        vec2 clamped = clamp(samplePos, 0.0, 1.0);
        vec3 s = texture(colortex0, clamped).rgb;
        float luma = dot(s, vec3(0.299, 0.587, 0.114));

        // Reject samples sitting on a block-light source (torch, lantern,
        // glowstone, etc.) so their warm glow can't masquerade as a sunbeam.
        float blockLight = texture(colortex1, clamped).r;
        float lightReject = 1.0 - smoothstep(GODRAY_BLOCKLIGHT_CUTOFF,
                                              GODRAY_BLOCKLIGHT_CUTOFF + GODRAY_BLOCKLIGHT_FEATHER,
                                              blockLight);

        accum += s * smoothstep(GODRAY_CANOPY_THRESHOLD, 1.0, luma) * lightReject * weight;
        weight *= 0.85;
    }
    accum /= float(GODRAY_SAMPLES);

    float edgeFade = 1.0 - smoothstep(0.6, 0.9, rayLen);
    return accum * edgeFade;
}
#endif

#ifdef ENABLE_SUNMOON_GLOW
vec3 computeGlow(vec3 lightDirEye, vec2 uv, float radius, float strength, vec3 tint) {
    vec4 clip = gbufferProjection * vec4(lightDirEye, 1.0);
    if (clip.w <= 0.0) return vec3(0.0); // behind the camera

    vec2 lightScreen = (clip.xy / clip.w) * 0.5 + 0.5;
    if (lightScreen.x < 0.0 || lightScreen.x > 1.0 ||
        lightScreen.y < 0.0 || lightScreen.y > 1.0) return vec3(0.0); // off-screen

    // Occlusion fix: don't glow if solid geometry (not sky) is sitting at
    // the sun/moon's own screen position - depthtex0 is the scene's
    // existing depth buffer, this is a single extra read, not a new pass.
    // Sky (nothing solid drawn) sits at/very near the far plane (~1.0);
    // anything closer means a block/mountain is actually in front of it.
    float sceneDepth = texture(depthtex0, lightScreen).r;
    float unoccluded = smoothstep(0.9990, 0.9999, sceneDepth);
    if (unoccluded <= 0.0) return vec3(0.0);

    // Aspect-correct the distance so the glow reads as a circle, not an
    // ellipse stretched to the window's width/height ratio.
    vec2 diff = uv - lightScreen;
    diff.x *= viewWidth / viewHeight;
    float dist = length(diff);
    if (dist > radius) return vec3(0.0); // cheap early-out

    float falloff = pow(clamp(1.0 - dist / radius, 0.0, 1.0), 2.0);
    return tint * falloff * strength * unoccluded;
}
#endif

void main() {
#ifdef DEBUG_TINT
    fragColor = vec4(1.0, 0.0, 1.0, 1.0);
    return;
#endif

    vec3 color = sanitize(texture(colortex0, texcoord).rgb);

#ifdef ENABLE_SHARPEN
    vec2 px = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec3 blur = sanitize(texture(colortex0, texcoord + vec2(px.x, 0.0)).rgb)
              + sanitize(texture(colortex0, texcoord - vec2(px.x, 0.0)).rgb)
              + sanitize(texture(colortex0, texcoord + vec2(0.0, px.y)).rgb)
              + sanitize(texture(colortex0, texcoord - vec2(0.0, px.y)).rgb);
    blur *= 0.25;
    color += (color - blur) * (SHARPEN_STRENGTH * SHADER_INTENSITY);
#endif

#ifdef ENABLE_GODRAYS
    // Sun only (moon godrays removed - see header note, this is also a
    // real perf win, not just a look change). Soft ceiling tames the
    // blow-up at high GODRAY_STRENGTH instead of a flat multiplier.
    vec3 rawRays = computeGodrays(sunPosition, texcoord);
    rawRays *= GODRAY_STRENGTH * SHADER_INTENSITY;
    vec3 rays = (rawRays / (1.0 + rawRays)) * GODRAY_SOFT_CEILING;
    color += rays;
#endif

#ifdef ENABLE_SUNMOON_GLOW
    color += computeGlow(sunPosition, texcoord, SUN_GLOW_RADIUS, SUN_GLOW_STRENGTH * SHADER_INTENSITY, SUN_GLOW_COLOR);
    color += computeGlow(moonPosition, texcoord, MOON_GLOW_RADIUS, MOON_GLOW_STRENGTH * SHADER_INTENSITY, MOON_GLOW_COLOR);
#endif

#ifdef ENABLE_CONTRAST
    color = adjustContrast(color, mix(1.0, BASE_CONTRAST, SHADER_INTENSITY));
#endif

#ifdef ENABLE_SATURATION
    color = adjustSaturation(color, mix(1.0, BASE_SATURATION, SHADER_INTENSITY));
#endif

#ifdef ENABLE_VIGNETTE
    vec2 centered = texcoord - 0.5;
    float vignette = 1.0 - dot(centered, centered) * VIGNETTE_STRENGTH * SHADER_INTENSITY;
    color *= clamp(vignette, 0.0, 1.0);
#endif

    // Dithering - breaks up color-banding into imperceptible noise instead
    // of a visible line. Interleaved Gradient Noise: one dot product, two
    // fract() calls, no texture reads.
    float dither = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    color += (dither - 0.5) / 255.0;

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
