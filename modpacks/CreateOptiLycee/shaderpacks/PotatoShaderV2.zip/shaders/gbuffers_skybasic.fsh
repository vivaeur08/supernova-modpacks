#version 120

/*
 * PotatoShade - gbuffers_skybasic.fsh
 * The sunrise/sunset horizon gradient and stars. Vanilla already sends
 * this quad a time-of-day-correct color via the vertex color, so instead
 * of hardcoding tick-based day/dusk/night windows (which risks not
 * matching vanilla's actual timing), this reacts to that incoming color:
 * naturally warm (dawn/dusk) colors get pushed richer, naturally dark
 * (night) colors get a slightly deeper custom blue instead of flat grey,
 * and everything gets a mild vibrance lift. No extra texture reads.
 */

#include "/lib/settings.glsl"

varying vec4 glcolor;

void main() {
    vec4 color = glcolor;

#ifdef ENABLE_SKY_ENHANCE
    float luma = dot(color.rgb, vec3(0.299, 0.587, 0.114));

    // Naturally warm (dawn/dusk) horizon colors: richer and more golden.
    float warmth = clamp(color.r - color.b, 0.0, 1.0);
    color.rgb = mix(color.rgb, color.rgb * vec3(1.18, 1.03, 0.88), warmth * SHADER_INTENSITY);

    // Naturally dark (night) sky: a touch of deep blue instead of flat grey/black.
    float darkness = 1.0 - smoothstep(0.0, 0.22, luma);
    color.rgb += vec3(0.01, 0.015, 0.045) * darkness * SHADER_INTENSITY;

    // General vibrance boost.
    color.rgb = mix(vec3(luma), color.rgb, mix(1.0, 1.15, SHADER_INTENSITY));
#endif

    gl_FragColor = color;
}
