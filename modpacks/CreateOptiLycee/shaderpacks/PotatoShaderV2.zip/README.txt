PotatoShade - a lightweight Iris shaderpack for very low-end PCs
====================================================================

CHANGELOG (v7 - this update)
------------------------------
- End terrain invisibility - ACTUALLY fixed this time, hopefully. The two
  previous attempts (v5's degenerate-fog-range guard, v6's NaN/buffer-
  clear guard) were both targeted at the shared root gbuffers_
  textured_lit.fsh/gbuffers_water.fsh, and a screenshot confirmed blocks
  were still not rendering after both - so those guesses were wrong, or
  at least incomplete. Rather than keep patching the shared code path
  blind, The End now gets its own dedicated, deliberately minimal
  override: shaders/world1/gbuffers_textured_lit.fsh and shaders/world1/
  gbuffers_water.fsh. These are as simple as a block shader can be - one
  texture read, one lightmap read, vertex color, single output. No fog
  math (gl_Fog.start/end are exactly what was under suspicion, so this
  version doesn't touch them at all), no multiple render targets, no
  division anywhere. TRADE-OFF, stated plainly: End terrain now skips
  fog, fake directional shading, and the torch-reject data - all minor
  there (small bounded space, and godrays are already off in the End
  regardless). Overworld and Nether are completely unaffected, still get
  the full version. If blocks STILL don't render in The End after this,
  the issue is very likely not in this shaderpack's code anymore, since
  this file has almost nothing left in it to be broken - at that point
  your exact Iris and Sodium version numbers would be the most useful
  next thing to see, alongside a screenshot.

CHANGELOG (v6)
------------------------------
- Attempted fix for the End's sky/void showing colorful static/noise
  (screenshot showed a grainy bright purple background instead of the
  End's normal dim near-black). HONEST NOTE UP FRONT: I can't run this on
  your actual GPU/driver to confirm the exact cause, so this is my best
  concrete diagnosis + fix, not a confirmed root cause. Two things changed:
    1. shaders.properties now explicitly forces colortex0/colortex1 to
       clear every frame (clear.colortex0=true, clear.colortex1=true).
       Previously this was left to Iris's/the driver's default - explicit
       is safer, since most of the End's sky is empty void with no sky
       dome mesh drawn into it (unlike the Overworld/Nether, where sky
       geometry always covers 100% of the screen), so if a buffer clear
       was ever skipped or handled inconsistently, that's exactly where
       it would show up as leftover/garbage data.
    2. Both final.fsh and world1/final.fsh now sanitize the color they
       read from colortex0 - explicitly replacing any NaN/Inf channel
       with 0 before any further math. This matters because clamp()'s
       behavior when fed NaN is implementation-defined per the GLSL spec
       (not guaranteed safe on every GPU/driver) - the pack's existing
       clamp() calls were NOT a reliable guard against this, only an
       explicit isnan()/isinf() check is. If NaN/Inf ever reaches
       colortex0 for any reason, this turns it into a plain black pixel
       instead of the chaotic per-pixel noise you saw.
  If this doesn't fully fix it, one thing that would help me narrow it
  down further: does the same grainy/static look ever show up in the
  Overworld or Nether (e.g. looking straight up, or right at the edge of
  render distance where chunks are still loading)? That would tell us
  whether this is specific to the End's empty void or a broader
  GPU/driver issue that's just hidden elsewhere by full sky coverage.

CHANGELOG (v5)
------------------------------
- FIXED: terrain invisible in The End (only sky/entities showing). Root
  cause found in the fog code shared by gbuffers_textured_lit.fsh,
  gbuffers_water.fsh, gbuffers_textured.fsh, and gbuffers_clouds.fsh: the
  divide-by-zero guard `max(gl_Fog.end - gl_Fog.start, 0.001)` was fine
  everywhere fog is normally configured, but The End doesn't use distance
  fog the way the Overworld/Nether do, so gl_Fog.start/end arrive equal
  (range 0) there - and that guard turned a "no fog configured" state
  into an almost-zero fog range instead, which snapped every block to
  100% fog color (near-black in the End's void) at virtually any
  distance. Entities stayed visible because things like an Enderman's
  glowing eyes render fullbright/fog-immune in vanilla regardless. Fixed
  by treating a degenerate (near-zero) fog range as "fog off" instead of
  "fog maxed out" - a one-line logic change in each of the 4 files, no
  visual change at all in the Overworld/Nether where fog was already
  configured normally.

CHANGELOG (v4)
------------------------------
- Godrays turned down again (default GODRAY_STRENGTH 0.75 -> 0.35, soft
  ceiling 0.50 -> 0.28) - if v3 still looked "too much" this should read
  as clearly more subtle, not just "not blinding at Maximum".
- Godrays are now SUN ONLY - moon godrays removed entirely per request.
  This is also a genuine, direct FPS win, not just a look change: the
  godray ray-march was previously running twice per frame (once per
  light) and is now down to once.
- Sun/moon glow FIXED - it was visible straight through terrain/mountains
  because it only ever checked the sun/moon's on-screen position, never
  whether anything solid was actually drawn there. It now reads the
  scene's existing depth buffer (depthtex0) at that exact spot and turns
  itself off if something solid is closer than the sky - one cheap extra
  read, not a new pass, so no meaningful FPS cost either way.
- Water reverted to fully default/vanilla-equivalent rendering per
  request: gbuffers_water.fsh no longer does fresnel, tint, sparkle, or
  wave-ripple at all - it's back to plain texture*lightmap*color+fog,
  same as if this file didn't exist. (It still quietly writes the
  torch-reject data for the godray system - invisible, no effect on how
  water looks.)

ON THE 60FPS ASK, HONESTLY
------------------------------
I can't benchmark your actual PC from here, so I won't promise a specific
number. What I can tell you factually: this pass is a single full-screen
post-process step plus small additions to shaders that were already
running - there's no shadow map, no second scene render, no deferred
G-buffer setup (the usual FPS-heavy parts of a "real" shaderpack), and
godrays now do half the sampling work they did last round. If you're
still under 60fps on default settings, on hardware like a GT 630 the more
likely bottleneck is Minecraft/Sodium itself (render distance, entities,
particles, chunk loading) rather than this shader - those settings are
worth checking too. If you can tell me your actual FPS with the shader on
vs. Sodium alone (shaders off), that number tells us whether the
remaining gap is this pack or the base game, and I can dig further from
there instead of guessing.

CHANGELOG (v3)
------------------------------
- Godrays now let some light through leaf canopy instead of treating any
  tree as a hard wall (lowered the "bright enough to count as light"
  threshold - see LEAF CANOPY note in final.fsh for the honest limits of
  this, it's still a straight-line sample, not per-gap raytracing).
- Godrays at "Maximum" strength no longer blind you / wash the screen to
  white - the ray contribution now runs through a soft (Reinhard-style)
  ceiling instead of adding linearly without bound.
- Sun and moon now get a soft colored glow (warm gold for the sun, cool
  blue-silver for the moon) computed in final.fsh. HONEST LIMIT: a shader
  can recolor/glow the EXISTING sun.png/moon_phases.png texture, it
  cannot swap in a different image/shape - that needs a resource pack.
- Water: root-caused the "lines" from the last update - the animated
  ripple had no hard bound and could sample past a tile's edge into a
  neighboring atlas texture on some layouts. Properly fixed now using
  Iris's mc_midTexCoord attribute to hard-clamp the offset inside each
  tile - this makes edge bleed impossible, not just unlikely. Also made
  the wave itself more visible (two overlapping wave frequencies instead
  of one, larger amplitude, safely bounded by the same clamp).
- The shaderpack's own "fake handheld dynamic light" feature has been
  DELETED from the code entirely (not just toggled off) per request - see
  "ABOUT LAMBDYNAMICLIGHTS" below for why this is a different thing from
  the actual LambDynamicLights mod, and how to turn that off if you have
  it installed.

CHANGELOG (v2)
------------------------
- Godrays were made a bit weaker by default (GODRAY_STRENGTH 1.0 -> 0.75,
  plus a lower internal scalar).
- Godrays stopped picking up torches/lanterns/glowstone/etc as fake
  sunbeams: gbuffers_textured_lit.fsh and gbuffers_water.fsh write a
  second, tiny "block light level" buffer (colortex1) alongside the
  normal image, and the godray pass in final.fsh reads it to reject any
  sample sitting on a light source.
- Water shimmer was fixed from camera-relative to world-relative (it used
  to visibly slide/swim when you only turned your head).
- shaders.properties + shaders/lang/en_us.lang added: real category tabs,
  human-readable option names, hover tooltips, instead of one flat list.

ABOUT LAMBDYNAMICLIGHTS
-----------------------------
LambDynamicLights is a separate Fabric mod (by LambdAurora), not part of
this shaderpack. It hooks into the game through its own mixins/rendering
code, entirely outside Iris's shader pipeline - a shader has no ability to
turn it off, because it isn't shader-controlled to begin with, and that's
still true after this update. This shaderpack DID have its own similarly-
named "fake handheld dynamic light" feature, and that code has now been
removed outright. If you also have the real LambDynamicLights mod
installed and want it off:
  1. Easiest: remove it from .minecraft/mods and relaunch.
  2. If you use Mod Menu + Cloth Config, open Mod Menu > LambDynamicLights
     > its config screen and disable it (or disable specific light
     sources like held torches) from there.
  3. Or edit its config file directly, typically
     .minecraft/config/lambdynamiclights.json - look for an "enabled" key
     (exact key names vary by mod version).
I can't edit that file for you since it isn't part of this shader zip -
if you paste its contents I can point out the exact line to change.

INSTALLATION
-------------
Do NOT unzip PotatoShade.zip. Put the .zip file itself into:
  .minecraft/shaderpacks/
Then in-game: Options > Video Settings > Shaderpacks > select "PotatoShade".
Click "Shader Options" to see all toggles/sliders below.

WHAT'S IN THIS VERSION
--------------------------
- Color grading: contrast, saturation, vignette, optional sharpen
- Dithering (fixes color-banding, e.g. at the sunset horizon)
- Godrays, sun only (screen-space approximation - see below for how/why)
- Fake directional "shading" (NOT real shadows - see below)
- Distance fog on terrain/entities/particles/clouds/water (matches vanilla)
- Sun/moon brightness lift + dedicated colored glow halo (depth-occluded,
  won't show through terrain)
- Custom-feeling day/dusk/night sky and cloud color push
- Softer, less "boxy" clouds
- Water: plain default/vanilla rendering (no special treatment)
- An End-dimension-specific override with gentler grading

IMPORTANT HONESTY SECTION - WHAT THIS IS AND ISN'T
--------------------------------------------------------
I want to be upfront about things I deliberately did NOT build the "real"
way, because the real way would very likely break 60fps on a GT 630:

1. GODRAYS are a screen-space approximation, not physically based, and
   sun-only (moon godrays were removed per request). Real godrays need a
   shadow map to know precisely what blocks the sun. This pack instead
   radially samples the already-rendered image toward the sun's on-screen
   position and keeps the bright-enough parts, rejecting anything that's
   actually a torch/lantern/etc rather than sky/sunlit-foliage. It looks
   reasonable and costs very little (it skips almost all its work the
   moment the sun isn't near the visible screen), but it won't produce
   perfectly crisp rays cut by a specific cliff edge, and it can't trace
   individual gaps between leaves the way real dappled forest light does -
   only 8-16 samples along one line per pixel, not per-leaf-gap raytracing.

2. "SHADOWS" in this pack are fake directional shading: faces angled
   toward the sun/moon get a bit brighter, faces angled away get a bit
   darker, using only each surface's own normal. There is NO shadow map
   and NO occlusion - a block sitting in the shade of another block will
   NOT go dark from this alone (vanilla's own baked lightmap still handles
   that part, same as without any shader). A true shadow-casting system
   means rendering the whole scene a second time from the sun's point of
   view, every frame - on a GT 630 that's very likely to cost more FPS
   than this hardware has to give. I did not add it, on purpose, to
   protect the 60fps target you asked for. If you want to experiment with
   it anyway and are willing to accept a real FPS hit to test it, tell me
   and I can build an optional, clearly-labeled expensive shadow pass -
   but I won't turn it on by default.

3. SUN/MOON GLOW recolors/glows the EXISTING vanilla sun.png/
   moon_phases.png texture that's already being rendered, and now checks
   scene depth so it hides behind terrain. It cannot replace that image
   with a genuinely different design/shape - a shader only processes
   pixels the game hands it, it can't swap in a new texture file. That
   would need a resource pack (textures/environment/sun.png etc.) - I can
   help build one if you want a specific look.

4. WATER is back to fully default/vanilla rendering (no fresnel, tint,
   sparkle, or wave-ripple) per request - see gbuffers_water.fsh. If the
   vanilla water texture itself looks "liney"/repetitive up close, that's
   the underlying vanilla texture, not something this shader is touching
   anymore - a resource pack would be the way to actually redraw it.

PERFORMANCE NOTES FOR YOUR HARDWARE
---------------------------------------
This is still deliberately cheap, but not literally zero-buffer anymore:
gbuffers_textured_lit.fsh and gbuffers_water.fsh now also write a second,
tiny 8-bit colortex1 buffer (the block-light mask godrays use to ignore
torches/lanterns) alongside the normal image - one extra lightweight
render target, still no extra render pass and no shadow map. The thing
that scales with viewing direction is still godrays: cost is highest
specifically when looking toward the sun (now half of what it was, since
moon godrays are gone), and near-zero otherwise. If you notice FPS dip
when looking at the sun, first try turning GODRAY_HIGH_QUALITY off (it
should already be off by default), then lower GODRAY_STRENGTH, then
disable ENABLE_GODRAYS entirely if needed - all adjustable live in Shader
Options, no file editing required. See "ON THE 60FPS ASK, HONESTLY" near
the top of this changelog for the bigger picture on frame rate.

END DIMENSION - HONEST UNCERTAINTY
---------------------------------------
The invisible-terrain bug (blocks missing, only sky/entities visible) took
three attempts to actually fix - see the v7 changelog entry above for
what finally worked (an isolated, minimal terrain shader just for the
End) and an honest account of why the first two guesses (v5, v6) didn't.
The separate "sky breaks after killing the Ender Dragon" issue is still
unconfirmed: I can't see what that actually looks like on your screen, so
shaders/world1/final.fsh remains a best-effort mitigation (much gentler
grading, no godrays, since the End's lighting is unusual - normally
near-black, then a scripted bright flash). If it's still wrong, a
screenshot of the broken End sky would let me actually diagnose it
instead of guessing again.

TROUBLESHOOTING
-------------------
- Red error screen with a file+line number: send me the exact text, I'll
  fix it directly rather than guess.
- Something looks visually wrong: a screenshot is genuinely the fastest
  way for me to help - I can reason about likely causes from a description,
  but I can't verify against your actual screen without seeing it.
- FPS lower than expected: work through the Shader Options toggles from
  most to least expensive: GODRAY_HIGH_QUALITY off -> lower GODRAY_STRENGTH
  -> ENABLE_GODRAYS off -> ENABLE_SHARPEN off (already off by default) ->
  ENABLE_FAKE_SHADING off. Also double check your general Minecraft/Sodium
  settings (render distance, particles, entity distance) since those
  affect FPS far more than this shaderpack does.

FILE STRUCTURE
------------------
PotatoShade.zip
  shaders/
    lib/settings.glsl              <- all options, one place
    final.vsh / final.fsh          <- color grading, dither, godrays,
                                       sun/moon glow, torch/leaf handling
    gbuffers_basic.*                <- untextured geometry (outlines)
    gbuffers_textured.*             <- unlit textured (particles etc)
    gbuffers_textured_lit.*         <- terrain/entities/hand/weather (fog,
                                        fake shading, block-light mask)
    gbuffers_skybasic.*             <- horizon gradient/stars
    gbuffers_skytextured.*          <- sun/moon texture itself
    gbuffers_clouds.*               <- clouds
    gbuffers_water.*                <- water (plain/default + block-light mask)
    world1/                          <- End dimension overrides:
      final.vsh, final.fsh             gentler grading, no godrays
      gbuffers_textured_lit.*          minimal terrain/entity renderer
      gbuffers_water.*                 minimal water renderer
    shaders.properties              <- in-game menu layout
    lang/en_us.lang                 <- in-game menu readable names/tooltips
  README.txt
