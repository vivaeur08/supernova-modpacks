execute as @a[scores={mine_lapis=1..}] at @s run playsound minecraft:la_peace_sound master @s ~ ~ ~ 1 1
execute as @a[scores={mine_deep=1..}] at @s run playsound minecraft:la_peace_sound master @s ~ ~ ~ 1 1
scoreboard players reset @a[scores={mine_lapis=1..}] mine_lapis
scoreboard players reset @a[scores={mine_deep=1..}] mine_deep
