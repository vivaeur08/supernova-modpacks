scoreboard objectives add mine_lapis mined:lapis_ore
scoreboard objectives add mine_deep mined:deepslate_lapis_ore
