stopsound @s record minecraft:la_peace_bgm
playsound minecraft:la_peace_bgm record @s ~ ~ ~ 1 1
tellraw @s {"text":"[La Peace] Playing BGM!","color":"light_purple"}
