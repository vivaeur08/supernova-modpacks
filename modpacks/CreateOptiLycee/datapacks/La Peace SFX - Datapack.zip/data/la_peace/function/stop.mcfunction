stopsound @s record minecraft:la_peace_bgm
tellraw @s {"text":"[La Peace] Stopped BGM.","color":"gray"}
