scoreboard players reset @s mine_lapis
scoreboard players reset @s mine_deepslate
playsound minecraft:la_peace_sound master @s ~ ~ ~ 1 1
